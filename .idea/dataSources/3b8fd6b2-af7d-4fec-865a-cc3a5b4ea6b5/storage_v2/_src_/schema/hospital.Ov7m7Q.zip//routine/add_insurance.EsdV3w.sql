create
    definer = root@`%` procedure add_insurance(IN new_insurance int, IN input_ssn varchar(9))
BEGIN
    IF EXISTS (SELECT * FROM Patient where ssn = input_ssn)
    THEN
        UPDATE Patient
        SET insurance_id = new_insurance
        WHERE ssn = input_ssn;
    ELSE SELECT 'There is no this patient in hospital';
    end IF;
END;

