create
    definer = root@`%` procedure SelectDoctorListByShift(IN FROM_TIME time, IN TO_TIME time, IN dname varchar(100), IN date date)
BEGIN
    SELECT *
    FROM Doctor
    WHERE dssn IN (
        SELECT doctor_ssn
        FROM Shift
        WHERE fromtime = FROM_TIME
          AND totime = TO_TIME
          AND date = shiftdate)
      AND departmentName = dname;
END;

