create
    definer = root@`%` procedure NEAREST_MEDICINE(IN SSN varchar(9))
begin
    declare prescription_ssn int;
    SET PRESCRIPTION_SSN = (SELECT pid
                            FROM Prescription
                            WHERE medicalExamination_id = (SELECT medical_examination_id
                                                            FROM Examination
                                                            WHERE patient_ssn = @SSN));
    SELECT medicine_name FROM PrescriptionHaveMedicine
    WHERE prescription_id = @PRESCRIPTION_SSN;
end;

