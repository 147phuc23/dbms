create
    definer = root@`%` procedure UPDATE_PATIENT_INFO(IN _ssn varchar(9), IN i_id varchar(225))
begin
    IF EXISTS (SELECT * FROM Patient WHERE SSN = _ssn) then
        UPDATE Patient
        SET Patient_name = Patient_name,
            insurance_id = i_id
        WHERE SSN = _ssn;

    ELSE
        SELECT 'There is no patient with this ssn in hospital';
    END IF;
END;

